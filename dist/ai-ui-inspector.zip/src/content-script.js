(function () {
  const PREFIX = "ai-inspector__";
  const ui = {};
  const state = {
    active: false,
    locked: false,
    hoverElement: null,
    currentElement: null
  };

  if (document.documentElement.dataset.aiInspectorMounted) {
    return;
  }
  document.documentElement.dataset.aiInspectorMounted = "true";

  function createPanel() {
    const panel = document.createElement("div");
    panel.className = `${PREFIX}panel`;
    panel.dataset.aiInspectorUi = "true";

    const header = document.createElement("div");
    header.className = `${PREFIX}panel-header`;

    const title = document.createElement("div");
    title.className = `${PREFIX}title`;
    title.textContent = "AI Inspector";

    const controls = document.createElement("div");
    controls.className = `${PREFIX}controls`;

    const toggleBtn = document.createElement("button");
    toggleBtn.className = `${PREFIX}button`;
    toggleBtn.textContent = "Start";
    toggleBtn.addEventListener("click", () => {
      if (state.active) {
        stopInspect();
      } else {
        startInspect();
      }
    });

    const unlockBtn = document.createElement("button");
    unlockBtn.className = `${PREFIX}button ${PREFIX}button--secondary`;
    unlockBtn.textContent = "Unlock";
    unlockBtn.disabled = true;
    unlockBtn.addEventListener("click", () => {
      unlock();
    });

    controls.append(toggleBtn, unlockBtn);

    header.append(title, controls);

    const status = document.createElement("div");
    status.className = `${PREFIX}status`;
    const dot = document.createElement("div");
    dot.className = `${PREFIX}dot`;
    const statusText = document.createElement("div");
    statusText.textContent = "Idle. Click Start to inspect.";
    status.append(dot, statusText);

    const hint = document.createElement("div");
    hint.className = `${PREFIX}hint`;
    hint.textContent =
      "Hover to highlight → Click to lock → Ctrl/Cmd + arrows to traverse. Esc to unlock.";

    const copyBtn = document.createElement("button");
    copyBtn.className = `${PREFIX}button`;
    copyBtn.textContent = "Copy LLM context";
    copyBtn.disabled = true;
    copyBtn.addEventListener("click", () => {
      copyContext();
    });

    panel.append(header, status, hint, copyBtn);
    document.body.appendChild(panel);

    ui.panel = panel;
    ui.toggleBtn = toggleBtn;
    ui.unlockBtn = unlockBtn;
    ui.statusText = statusText;
    ui.statusDot = dot;
    ui.copyBtn = copyBtn;
  }

  function createHighlight() {
    const highlight = document.createElement("div");
    highlight.className = `${PREFIX}highlight`;
    highlight.style.display = "none";
    highlight.dataset.aiInspectorUi = "true";

    const label = document.createElement("div");
    label.className = `${PREFIX}label`;
    label.style.display = "none";
    label.dataset.aiInspectorUi = "true";

    document.body.appendChild(highlight);
    document.body.appendChild(label);

    ui.highlight = highlight;
    ui.label = label;
  }

  function createToast() {
    const toast = document.createElement("div");
    toast.className = `${PREFIX}toast`;
    toast.dataset.aiInspectorUi = "true";
    document.body.appendChild(toast);
    ui.toast = toast;
  }

  function showToast(message) {
    if (!ui.toast) return;
    ui.toast.textContent = message;
    ui.toast.classList.add(`${PREFIX}toast--visible`);
    setTimeout(() => ui.toast.classList.remove(`${PREFIX}toast--visible`), 1500);
  }

  function isInspectorUi(el) {
    if (!el) return false;
    return Boolean(el.closest("[data-ai-inspector-ui='true']"));
  }

  function startInspect() {
    state.active = true;
    ui.toggleBtn.textContent = "Stop";
    ui.statusText.textContent = "Inspecting. Hover and click to lock.";
    ui.statusDot.classList.add(`${PREFIX}dot--active`);
    ui.copyBtn.disabled = false;
    document.addEventListener("mousemove", handleMouseMove, true);
    document.addEventListener("click", handleClick, true);
    document.addEventListener("keydown", handleKeyDown, true);
  }

  function stopInspect() {
    state.active = false;
    state.locked = false;
    state.currentElement = null;
    state.hoverElement = null;
    ui.toggleBtn.textContent = "Start";
    ui.statusText.textContent = "Idle. Click Start to inspect.";
    ui.statusDot.classList.remove(`${PREFIX}dot--active`);
    ui.unlockBtn.disabled = true;
    ui.copyBtn.disabled = true;
    clearHighlight();
    document.removeEventListener("mousemove", handleMouseMove, true);
    document.removeEventListener("click", handleClick, true);
    document.removeEventListener("keydown", handleKeyDown, true);
  }

  function unlock() {
    if (!state.locked) return;
    state.locked = false;
    state.currentElement = null;
    ui.unlockBtn.disabled = true;
    ui.statusText.textContent = "Unlocked. Hover or click to lock again.";
    if (state.hoverElement) {
      updateHighlight(state.hoverElement);
    } else {
      clearHighlight();
    }
  }

  function handleMouseMove(event) {
    if (!state.active || state.locked) return;
    const target = findTarget(event.target);
    if (!target || target === state.hoverElement) return;
    state.hoverElement = target;
    updateHighlight(target);
  }

  function handleClick(event) {
    if (!state.active) return;
    const target = findTarget(event.target);
    if (!target) return;
    event.preventDefault();
    event.stopPropagation();
    state.locked = true;
    state.currentElement = target;
    ui.unlockBtn.disabled = false;
    ui.statusText.textContent = "Locked. Use Ctrl/Cmd + arrows to move. Esc to unlock.";
    updateHighlight(target);
  }

  function handleKeyDown(event) {
    if (!state.active) return;
    if (event.key === "Escape" && state.locked) {
      unlock();
      return;
    }
    if (!state.locked || !state.currentElement) return;
    if (!(event.metaKey || event.ctrlKey)) return;
    let next = null;
    if (event.key === "ArrowUp") {
      next = state.currentElement.parentElement;
    } else if (event.key === "ArrowDown") {
      next = state.currentElement.firstElementChild;
    } else if (event.key === "ArrowLeft") {
      next = state.currentElement.previousElementSibling;
    } else if (event.key === "ArrowRight") {
      next = state.currentElement.nextElementSibling;
    }
    if (next) {
      event.preventDefault();
      state.currentElement = next;
      updateHighlight(next);
    }
  }

  function findTarget(node) {
    let el = node;
    while (el) {
      if (isInspectorUi(el)) return null;
      if (el.nodeType === Node.ELEMENT_NODE) return el;
      el = el.parentElement;
    }
    return null;
  }

  function updateHighlight(element) {
    if (!ui.highlight || !ui.label) return;
    const rect = element.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) {
      clearHighlight();
      return;
    }
    ui.highlight.style.display = "block";
    ui.highlight.style.top = `${rect.top}px`;
    ui.highlight.style.left = `${rect.left}px`;
    ui.highlight.style.width = `${rect.width}px`;
    ui.highlight.style.height = `${rect.height}px`;

    const labelText = describeElement(element);
    ui.label.textContent = labelText;
    ui.label.style.display = "block";
    const labelOffset = 8;
    let top = rect.top - ui.label.offsetHeight - labelOffset;
    if (top < 8) top = rect.bottom + labelOffset;
    let left = rect.left;
    const maxLeft = window.innerWidth - ui.label.offsetWidth - 8;
    if (left > maxLeft) left = maxLeft;
    ui.label.style.top = `${top}px`;
    ui.label.style.left = `${left}px`;
  }

  function clearHighlight() {
    if (ui.highlight) ui.highlight.style.display = "none";
    if (ui.label) ui.label.style.display = "none";
  }

  function describeElement(el) {
    const tag = el.tagName ? el.tagName.toLowerCase() : "element";
    const id = el.id ? `#${el.id}` : "";
    const classes = (el.className && typeof el.className === "string"
      ? el.className
      : "")
      .split(" ")
      .filter(Boolean)
      .slice(0, 3)
      .map((cls) => `.${cls}`)
      .join("");
    return `${tag}${id}${classes}`;
  }

  async function copyContext() {
    const target = state.currentElement || state.hoverElement;
    if (!target) {
      showToast("Select an element first.");
      return;
    }
    const payload = buildPayload(target);
    try {
      await writeClipboard(payload);
      showToast("Context copied for LLM.");
    } catch (err) {
      console.error(err);
      showToast("Copy failed. Check clipboard permissions.");
    }
  }

  function buildPayload(el) {
    const rect = el.getBoundingClientRect();
    const style = window.getComputedStyle(el);
    const styleKeys = [
      "display",
      "position",
      "top",
      "left",
      "right",
      "bottom",
      "width",
      "height",
      "margin",
      "padding",
      "gap",
      "flex",
      "align-items",
      "justify-content",
      "grid-template-columns",
      "grid-template-rows",
      "background-color",
      "color",
      "font-size",
      "font-family",
      "line-height",
      "border",
      "border-radius",
      "box-shadow",
      "opacity",
      "overflow",
      "z-index"
    ];
    const styleLines = styleKeys
      .map((key) => {
        const value = style.getPropertyValue(key);
        return value ? `${key}: ${value}` : "";
      })
      .filter(Boolean);

    const attrs = collectAttributes(el);
    const reactSource = readReactSource(el);
    const htmlSnippet = formatHtml(el.outerHTML, 1800);
    const textPreview = (el.innerText || el.textContent || "")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 240);
    const dataset = Object.entries(el.dataset || {});

    const lines = [];
    lines.push("[Context] Selected element from AI Inspector");
    lines.push(`Selector: ${describeElement(el)}`);
    lines.push(`DOM path: ${buildDomPath(el)}`);
    lines.push(
      `Viewport box: x=${Math.round(rect.x)}, y=${Math.round(
        rect.y
      )}, w=${Math.round(rect.width)}, h=${Math.round(rect.height)}`
    );
    if (textPreview) lines.push(`Text preview: "${textPreview}"`);
    if (attrs.length) lines.push(`Attributes: ${attrs.join(", ")}`);
    if (dataset.length) {
      const ds = dataset
        .map(([k, v]) => `data-${k}="${v}"`)
        .join(", ");
      lines.push(`Dataset: ${ds}`);
    }
    if (reactSource) {
      lines.push(
        `React source (dev only): ${reactSource.fileName}:${reactSource.lineNumber}`
      );
    }
    lines.push("");
    lines.push("Key styles:");
    lines.push(...styleLines.map((l) => `- ${l}`));
    lines.push("");
    lines.push("HTML snippet:");
    lines.push(htmlSnippet);

    return lines.join("\n");
  }

  function collectAttributes(el) {
    const attrNames = ["id", "class", "role", "aria-label", "aria-describedby"];
    const attrs = [];
    attrNames.forEach((name) => {
      const value = el.getAttribute(name);
      if (value) attrs.push(`${name}="${value}"`);
    });
    return attrs;
  }

  function buildDomPath(el) {
    const segments = [];
    let node = el;
    while (node && node.nodeType === Node.ELEMENT_NODE && segments.length < 8) {
      const part = describeElement(node);
      segments.unshift(part);
      node = node.parentElement;
    }
    return segments.join(" > ");
  }

  function readReactSource(el) {
    const keys = Object.keys(el || {}).filter(
      (k) => k.startsWith("__reactFiber") || k.startsWith("__reactProps")
    );
    for (const key of keys) {
      const fiber = el[key];
      let node = fiber;
      while (node) {
        if (node._debugSource) {
          return node._debugSource;
        }
        node = node.return;
      }
    }
    return null;
  }

  function formatHtml(html, limit) {
    const trimmed = (html || "").trim();
    if (trimmed.length <= limit) return trimmed;
    return `${trimmed.slice(0, limit)}... (truncated)`;
  }

  async function writeClipboard(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text);
    }
    return legacyCopy(text);
  }

  function legacyCopy(text) {
    return new Promise((resolve, reject) => {
      const textarea = document.createElement("textarea");
      textarea.value = text;
      textarea.style.position = "fixed";
      textarea.style.top = "-9999px";
      textarea.style.left = "-9999px";
      textarea.dataset.aiInspectorUi = "true";
      document.body.appendChild(textarea);
      textarea.select();
      try {
        const success = document.execCommand("copy");
        document.body.removeChild(textarea);
        success ? resolve() : reject(new Error("execCommand failed"));
      } catch (err) {
        document.body.removeChild(textarea);
        reject(err);
      }
    });
  }

  createPanel();
  createHighlight();
  createToast();
})();
